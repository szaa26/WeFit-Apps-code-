<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Booking;
use App\Models\BookingDetail;
use App\Models\BookingTimeDetail;
use App\Models\Venue;
use App\Models\VenueField;
use App\Models\SportTools;

class OrderController extends Controller
{
   public function index(Request $request)
    {
        $session_user   = $request->session()->get('auth_user');
        if ($session_user->roles == 'admin') {
            $data = Booking::with(['venue', 'user_member'])->orderBy('id', 'DESC')->get()->all();
        }else{
            // Get By owned venye
            $owned_venue = Venue::where('user_id', $session_user->id)->get()->all();
            $venue_ids    = [];
            foreach ($owned_venue as $key => $value) {
                $venue_ids[] = $value->id;
            }
            $data = Booking::with(['venue', 'user_member'])->whereIn('venue_id', $venue_ids)->orderBy('id', 'DESC')->get()->all();
        }


        foreach ($data as $key => $value) {
            // Get Booking Detail
            $bookingDetail = BookingDetail::where('booking_id', $value->id)->get()->all();
            $booking_detail_arr = [];
            foreach ($bookingDetail as $bkey => $bvalue) {

                $tmp_data = [];
                if ($bvalue->type == "field") {
                    // Get field name
                    $field = VenueField::where('id', $bvalue->venue_field_id)->withTrashed()->first();
                    $tmp_data['item_name'] = $field->field_name;
                }else{
                    // Get tools name
                    $tools = SportTools::where('id', $bvalue->sport_tools_id)->withTrashed()->first();
                    $tmp_data['item_name'] = $tools->tools_name;
                }
            
                $tmp_data['price']       = $bvalue->price;
                $tmp_data['qty']         = $bvalue->qty;
                $tmp_data['total_price'] = $bvalue->total_price;

                $booking_detail_arr[] = $tmp_data;
            }

            $data[$key]['booking_detail'] = $booking_detail_arr;

            // Get Booking Time
            $time = BookingTimeDetail::with(['time_data'])->where('booking_id', $value->id)->get()->all();
            $data[$key]['time_data'] = $time;
        }
        // debugCode($data);
        return view('order.index', compact('data'));
    }

    public function cancelOrder(Request $request, $id)
    {
        $data = Booking::find($id);
        $data->status = 2;
        $data->save();
        return redirect()->back()->with('success', 'Cancel order success.!');
    }
}
