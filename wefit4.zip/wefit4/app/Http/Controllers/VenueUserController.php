<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Province;
use App\Models\Regency;
use Illuminate\Support\Facades\Hash;

class VenueUserController extends Controller
{
    public function index()
    {
        $data    = User::with(['regency', 'province'])->where('roles', 'venue')->get()->all();
        return view('user_venue.index', compact('data'));
    }

    public function create()
    {
        $province = Province::orderBy('name', 'ASC')->get()->all();
        // debugCode($province);
        return view('user_venue.create', compact('province'));
    }

    public function store(Request $request)
    {
        $checkUser = User::where('email', $request->email)
            ->first();

        if (!empty($checkUser)) {
            return redirect()->back()->with('error', 'Email already exists.!');
        }

        $data = new User;
        $data->name        = $request->name;
        $data->email       = $request->email;
        $data->phone       = $request->phone;
        $data->province_id = $request->province;
        $data->regency_id  = $request->city;
        $data->password    = Hash::make($request->password);
        $data->roles       = 'venue';
        $data->save();

        return redirect('/venue-users')->with('success','Add data success.!');
    }

    public function show($id)
    {
        $data     = User::find($id);
        $province = Province::orderBy('name', 'ASC')->get()->all();
        $city     = Regency::where('province_id', $data->province_id)
            ->orderBy('name', 'ASC')
            ->get()->all();
        return view('user_venue.edit',compact('data', 'province', 'city'));
    }

    public function update(Request $request, $id)
    {

        $checkUser = User::where('email', $request->email)
            ->where('id', '!=', $id)
            ->first();

        if (!empty($checkUser)) {
            return redirect('/venue-users')->with('error', 'Email already exists.!');
        }

        $data = User::find($id);
        $data->name        = $request->name;
        $data->email       = $request->email;
        $data->phone       = $request->phone;
        $data->province_id = $request->province;
        $data->regency_id  = $request->city;
        $data->password    = $request->password != '' ? Hash::make($request->password) : $data->password;
        $data->save();

        return redirect('/venue-users')->with('success','Update data success.!');
    }

    public function destroy($id)
    {
        User::find($id)->delete();
        return redirect('/venue-users')->with('success','Delete data success.!');
    }
}
