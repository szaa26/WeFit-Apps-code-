<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Venue;
use App\Models\SportTools;

class SportToolsController extends Controller
{
    public function index(Request $request)
    {
        $session_user   = $request->session()->get('auth_user');
        
        if ($session_user->roles == 'admin') {
            $data = SportTools::with(['venue'])->get()->all();
        }else{
            // Get By owned venye
            $owned_venue = Venue::where('user_id', $session_user->id)->get()->all();
            $venue_id    = [];
            foreach ($owned_venue as $key => $value) {
                $venue_id[] = $value->id;
            }

            $data = SportTools::with(['venue'])->whereIn('venue_id', $venue_id)->get()->all();
        }
        
        return view('sport_tools.index', compact('data'));
    }

    public function create(Request $request)
    {
        $session_user   = $request->session()->get('auth_user');
        if ($session_user->roles == 'admin') {
            $venue = Venue::orderBy('venue_name', 'ASC')->get()->all();
        }else{
            $venue = Venue::where('user_id', $session_user->id)->orderBy('venue_name', 'ASC')->get()->all();
        }
        return view('sport_tools.create', compact('venue'));
    }

    public function store(Request $request)
    {
        $data = new SportTools;
        $data->venue_id   = $request->venue;
        $data->tools_name = $request->name;
        $data->price      = $request->price;
        $data->save();

        return redirect('/sport-tools')->with('success','Add data success.!');
    }

    public function show($id)
    {
        $data  = SportTools::find($id);
        $venue = Venue::orderBy('venue_name', 'ASC')->get()->all();
        return view('sport_tools.edit',compact('data', 'venue'));
    }

    public function update(Request $request, $id)
    {
        $data = SportTools::find($id);
        $data->venue_id   = $request->venue;
        $data->tools_name = $request->name;
        $data->price      = $request->price;
        $data->save();

        return redirect('/sport-tools')->with('success','Update data success.!');
    }

    public function destroy($id)
    {
        SportTools::find($id)->delete();
        return redirect('/sport-tools')->with('success','Delete data success.!');
    }
}
