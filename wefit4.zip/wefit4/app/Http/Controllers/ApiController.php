<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use App\Models\User;
use App\Models\UserMember;
use App\Models\Province;
use App\Models\Regency;
use App\Models\Category;
use App\Models\Venue;
use App\Models\VenueField;
use App\Models\TimeData;
use App\Models\Booking;
use App\Models\BookingDetail;
use App\Models\BookingTimeDetail;
use App\Models\SportTools;
use App\Models\DuitkuCallbackLog;
use App\Models\Team;
use App\Models\MatchmakingLobby;
use App\Models\MatchmakingLobbyRequest;

class ApiController extends Controller
{

    public function getProvince(Request $request)
    {
        $data = Province::orderBy('name', 'ASC')->get()->all();
        return returnAPI(200, 'Success', $data);
    }

    public function getCity(Request $request)
    {
        $data = Regency::where('province_id', $request->province_id)
            ->orderBy('name', 'ASC')
            ->get()->all();
        return returnAPI(200, 'Success', $data);
    }


    /*
    * Register
    */
    public function login(Request $request)
    {
        $data = UserMember::where('email', $request->email)
            ->first();

        if (!empty($data)) {
            if (Hash::check($request->password, $data->password)) {
                return returnAPI(200, 'Success', $data);
            }else{
                return returnAPI(202, 'Incorrect Password.!');
            }
        }else{
            return returnAPI(201, 'Email not found.!');
        }
    }

    public function register(Request $request)
    {
        $checkUser = UserMember::where('email', $request->email)
            ->first();

        if (!empty($checkUser)) {
            return returnAPI(201, 'Email already exists');
        }

        $data              = new UserMember;
        $data->name        = $request->name;
        $data->email       = $request->email;
        $data->phone       = $request->phone;
        $data->address     = $request->address;
        $data->province_id = $request->province;
        $data->regency_id  = $request->city;
        $data->password    = Hash::make($request->password);
        $data->save();

        return returnAPI(200, 'Register Success', $data);
    }

    /*
    * Profile
    */
    public function profile(Request $request)
    {
        $data = UserMember::with(['province', 'regency'])->where('id', $request->id)->first();
        return returnAPI(200, 'Success', $data);
    }

    public function updateProfile(Request $request)
    {
        $id = $request->id;
        $checkUser = UserMember::where('email', $request->email)
            ->where('id', '!=', $id)
            ->first();

        if (!empty($checkUser)) {
            return returnAPI(201, 'Email already exists');
        }

        $data = UserMember::find($id);
        $data->name        = $request->name;
        $data->email       = $request->email;
        $data->phone       = $request->phone;
        $data->address     = $request->address;
        $data->province_id = $request->province;
        $data->regency_id  = $request->city;
        $data->save();

        return returnAPI(200, 'Update Profile Success', $data);
    }

    public function updatePasswordMember(Request $request)
    {
        $data = UserMember::find($request->id);
        $data->password = Hash::make($request->password);

        return returnAPI(200, 'Update Password Success', $data);
    }


    /*
    * Data Field
    */

    public function category(Request $request)
    {
        $data = Category::get()->all();
        foreach ($data as $key => $value) {
            $data[$key]->banner_url = url('/banner/'.$value->banner_image);
        }

        return returnAPI(200, 'Success', $data);
    }

    public function venue(Request $request)
    {
        $data = Venue::join('venue_field', 'venue_field.venue_id', '=', 'venue.id')
            ->select('venue.*', 'venue_field.price')
            ->groupBy('venue_field.venue_id');

        /* If category id */
        if ($request->category_id != null) {
            if ($request->category_id != "") {
                $data->where('venue_field.category_id', $request->category_id);
            }
        }

        /* If province */
        if ($request->province != null) {
            if ($request->province != '') {
                $data->where('venue.province_id', $request->province);
            }
        }

        /* If city */
        if ($request->city != null) {
            if ($request->city != '') {
                $data->where('venue.regency_id', $request->city);
            }
        }
        $data = $data->get()->all();

        foreach ($data as $key => $value) {
            $data[$key]->map_link = 'https://www.google.com/maps/search/?api=1&query='.$value->lat.','.$value->lng;
            $data[$key]->price_format = 'Rp. '.number_format($value->price);
        }

        return returnAPI(200, 'Success', $data);
    }

    public function venueDetail(Request $request)
    {
        $id = $request->id;
        $data = Venue::where('id', $id)->first();

        // Ambil List Lapangan per category
        // $data->filed_list = [];
        $category = Category::get()->all();
        $tmp_field = [];
        foreach ($category as $key => $value) {
            $field = VenueField::where('venue_id', $id)
                ->where('category_id', $value->id)
                ->get()->all();

            foreach ($field as $fkey => $fvalue) {
                $field[$fkey]->price_format = 'Rp. '.number_format($fvalue['price']);
            }
            if (!empty($field)) {
                $tmp_field[] = ['category' => $value->category_name, 'field' => $field];
            }
        }
        $data->field_list = $tmp_field;
        $data->map_link   = 'https://www.google.com/maps/search/?api=1&query='.$data->lat.','.$data->lng;
        return returnAPI(200, 'Success', $data);
    }

    public function venueFieldDetail(Request $request)
    {
        $id   = $request->id;
        $date = $request->booking_date;

        $data = VenueField::where('id', $id)->first();
        if (!empty($data)) {
            $data->price_format = 'Rp. '.number_format($data['price']);
        }

        // Get Open Time
        $venue = Venue::find($data->venue_id);
        $timeData = TimeData::where('start_time', '>=', $venue->open_time)
            ->where('end_time', '<=', $venue->close_time)->get()->all();

        foreach ($timeData as $key => $value) {
            // Check Availibility
            $checkTime = BookingTimeDetail::join('booking', 'booking.id', 'booking_time_detail.booking_id')
                ->where('time_data_id', $value->id)
                ->where('booking_date', $date)
                ->where('booking.status', '!=', 2)
                ->where('venue_field_id', $id)->first();
            if ($checkTime!='') {
                $timeData[$key]->available = 'NO';
            }else{
                $timeData[$key]->available = 'YES';
            }
        }
        $data->time_data = $timeData;

        // Get Sport Tools
        $tools = SportTools::where('venue_id', $venue->id)->get()->all();
        foreach ($tools as $key => $value) {
            $tools[$key]->price_format = 'Rp. '.number_format($value->price);
        }
        $data->sport_tools = $tools;
        return returnAPI(200, 'Success', $data);
    }

    /*
    * Booking Data
    */
    public function checkBookingPrice(Request $request)
    {

        $item = [];

        $venue = Venue::where('id', $request->venue_id)->first();
        $field = VenueField::where('id', $request->field_id)->first();


        $time_booking = $request->time_ids;
        asort($time_booking);
        $booking_time = TimeData::whereIn('id', $request->time_ids)->get()->all();
        $times        = [];
        foreach ($booking_time as $key => $value) {
            $times[] = substr($value->start_time, 0,5).' - '.substr($value->end_time,0,5);
        }

        $data_place = [
            'name'      => $field->field_name.' ('.implode(', ', $times).')',
            'qty'       => count($times),
            'sub_price' => "Rp. ".number_format($field->price),
            'price'     => "Rp. ".number_format($field->price*count($times)),
            'price_int' => $field->price*count($times)
        ];


        /* Add data place */
        $item[] = $data_place;

        /* Add data sport tools */
        if ($request->sport_tools_ids != null) {
            if (!empty($request->sport_tools_ids)) {
                $sport_tools = SportTools::whereIn('id', $request->sport_tools_ids)
                    ->get()->all();

                foreach ($sport_tools as $key => $value) {
                    $data_tools = [
                        'name'      => $value->tools_name,
                        'qty'       => 1,
                        'sub_price' => "Rp. ".number_format($value->price),
                        'price'     => "Rp. ".number_format($value->price),
                        'price_int' => $value->price
                    ];
                    $item[] = $data_tools;
                }
            }
        }

        $total = 0;
        foreach ($item as $key => $value) {
            $total+=$value['price_int'];
        }


        $data = [
            'venue'     => $venue,
            'items'     => $item,
            'total'     => "Rp. ".number_format($total),
            'total_int' => $total,
        ];

        return returnAPI(200, 'Success', $data);
    }

    public function doBooking(Request $request)
    {
        $item = [];

        $venue = Venue::where('id', $request->venue_id)->first();
        $field = VenueField::where('id', $request->field_id)->first();


        $time_booking = $request->time_ids;
        asort($time_booking);
        $booking_time = TimeData::whereIn('id', $request->time_ids)->get()->all();
        $times        = [];
        foreach ($booking_time as $key => $value) {
            $times[] = substr($value->start_time, 0,5).' - '.substr($value->end_time,0,5);
        }

        $start_play = $booking_time[0]->start_time;
        $end_play   = $booking_time[count($booking_time)-1]->end_time;

        $data_place = [
            'name'      => $field->field_name.' ('.implode(', ', $times).')',
            'qty'       => count($times),
            'sub_price' => "Rp. ".number_format($field->price),
            'price'     => "Rp. ".number_format($field->price*count($times)),
            'price_int' => $field->price*count($times),
            'type'      => 'field',
            'id'        => $field->id
        ];


        /* Add data place */
        $item[] = $data_place;

        /* Add data sport tools */
        if ($request->sport_tools_ids != null) {
            if (!empty($request->sport_tools_ids)) {
                $sport_tools = SportTools::whereIn('id', $request->sport_tools_ids)
                    ->get()->all();

                foreach ($sport_tools as $key => $value) {
                    $data_tools = [
                        'name'      => $value->tools_name,
                        'qty'       => 1,
                        'sub_price' => "Rp. ".number_format($value->price),
                        'price'     => "Rp. ".number_format($value->price),
                        'price_int' => $value->price,
                        'type'      => 'tools',
                        'id'        => $value->id
                    ];
                    $item[] = $data_tools;
                }
            }
        }

        $total = 0;
        foreach ($item as $key => $value) {
            $total+=$value['price_int'];
        }


        $data = [
            'venue'     => $venue,
            'items'     => $item,
            'total'     => "Rp. ".number_format($total),
            'total_int' => $total,
        ];

        // Masukan data ke booking
        $booking = new Booking;
        $booking->venue_id          = $request->venue_id;
        $booking->venue_field_id    = $request->field_id;
        $booking->user_member_id    = $request->user_id;
        $booking->invoice_no        = generate_booking_code();
        $booking->booking_date      = $request->booking_date;
        $booking->start_play        = $start_play;
        $booking->end_play          = $end_play;
        $booking->status            = 0;
        $booking->withdrawal_status = 0;
        $booking->total_payment     = $data['total_int'];
        $booking->save();

        // Masukan data ke booking detail
        foreach ($data['items'] as $key => $value) {
            $bDetail = new BookingDetail;
            $bDetail->booking_id     = $booking->id;
            $bDetail->type           = $value['type'];
            $bDetail->venue_field_id = ($value['type'] == 'field')?$value['id']:0;
            $bDetail->sport_tools_id = ($value['type'] == 'tools')?$value['id']:0;
            $bDetail->price          = $value['price_int']/$value['qty'];
            $bDetail->qty            = $value['qty'];
            $bDetail->total_price    = $value['price_int'];
            $bDetail->save();
        }

        // Masukan data ke booking time detail
        foreach ($booking_time as $key => $value) {
            $bTime = new BookingTimeDetail;
            $bTime->booking_id   = $booking->id;
            $bTime->time_data_id = $value->id;
            $bTime->save();
        }

        return returnAPI(200, 'Booking Complete, continue to payment.!', $booking);
    }

    public function bookingHistory(Request $request)
    {
        $user_member_id = $request->user_member_id;

        $booking = Booking::with(['venue', 'venue_field'])->where('user_member_id', $user_member_id)
            ->orderBy('created_at', 'DESC')
            ->get()->all();

        foreach ($booking as $key => $value) {
            $booking[$key]->status_text          = status_booking($value->status);
            $booking[$key]->total_payment_format = 'Rp.'. number_format($value->total_payment);
        }
        return returnAPI(200, 'Success', $booking);
    }

    public function bookingDetail(Request $request)
    {
        $id = $request->booking_id;
        $booking = Booking::with(['venue', 'user_member'])->where('id', $id)
            ->first();
        $booking->total_payment_text = 'Rp. '.number_format($booking->total_payment);
        $booking->status_text        = status_booking($booking->status);

        $bookingDetail = BookingDetail::where('booking_id', $id)->get()->all();

        $itemDetails = [];
        foreach ($bookingDetail as $key => $value) {
            if ($value->type == 'field') {
                $field = VenueField::where('id', $value->venue_field_id)->withTrashed()->first();
                $itemDetails[] = [
                    'name'             => $field->field_name.' '.$value->qty.' Hour',
                    'price'            => (int)$value->price,
                    'price_text'       => 'Rp. '.number_format((int)$value->price),
                    'total_price'      => $value->total_price,
                    'total_price_text' => 'Rp.'.number_format($value->total_price),
                    'quantity'         => $value->qty
                ];
            }else{
                $tools = SportTools::where('id', $value->sport_tools_id)->withTrashed()->first();
                $itemDetails[] = [
                    'name'             => $tools->tools_name,
                    'price'            => (int)$value->price,
                    'price_text'       => 'Rp. '.number_format((int)$value->price),
                    'total_price'      => $value->total_price,
                    'total_price_text' => 'Rp.'.number_format($value->total_price),
                    'quantity'         => $value->qty
                ];
            }
        }

        $booking->item = $itemDetails;
        return returnAPI(200, 'Success', $booking);
    }

    /*
    * Team & Lawan Tanding
    */
    public function createTeam(Request $request)
    {
        $checkIsOnteam = Team::where('user_member_id', $request->user_member_id)->first();

        if (!empty($checkIsOnteam)) {
            return returnAPI(201, 'You already have your own team.!'); 
        }

        $data = new Team;
        $data->team_name      = $request->team_name;
        $data->description    = $request->description;
        $data->member         = json_encode($request->members);
        $data->user_member_id = $request->user_member_id;
        $data->save();

        return returnAPI(200, 'Create team success', $data);
    }

    public function detailTeamUser(Request $request)
    {
        $data = Team::where('user_member_id', $request->user_member_id)->first();
        if (!empty($data)) {
            $data->member = json_decode($data->member);
        }else{
            $data = [];
        }

        return returnAPI(200, 'Success', $data);
    }

    public function updateTeam(Request $request)
    {
        $data = Team::find($request->team_id);
        $data->team_name      = $request->team_name;
        $data->description    = $request->description;
        $data->member         = json_encode($request->members);
        $data->user_member_id = $request->user_member_id;
        $data->save();

        return returnAPI(200, 'Update Team Success.!', $data);
    }

    public function create_mm_lobby(Request $request)
    {
        $data = new MatchmakingLobby;
        $data->team_id     = $request->team_id;
        $data->venue_id    = $request->venue_id;
        $data->category_id = $request->category_id;
        $data->title       = $request->title;
        $data->description = $request->description;
        $data->status      = '';
        $data->save();

        return returnAPI(200, 'Matchmaking Created.!');
    }

    public function list_mm_lobby(Request $request)
    {
        $data = MatchmakingLobby::with(['venue', 'team', 'category'])->orderBy('id', 'DESC')->where('status', 0);
        if ($request->venue_id != null) {
            $data = $data->where('venue_id', $request->venue_id);
        }

        $data = $data->get()->all();

        return returnAPI(200, 'Success', $data);
    }

    public function requestJoinMatch(Request $request)
    {
        $team = Team::where('user_member_id', $request->user_member_id)
            ->get()->first();

        if (empty($team)) {
            return returnAPI(201, 'You do not have team.! Create team first.!');
        }

        $check = MatchmakingLobbyRequest::where('matchmaking_lobby_id', $request->match_id)
            ->where('team_id', $team->id)
            ->first();
        if (!empty($check)) {
            return returnAPI(201, 'You already request on this match.!');
        }

        $data = new MatchmakingLobbyRequest;
        $data->matchmaking_lobby_id = $request->match_id;
        $data->team_id              = $team->id;
        $data->save();

        return returnAPI(200, 'Request Success.!');
    }

    public function matchDetail(Request $request)
    {
        $match = MatchmakingLobby::with(['venue', 'team', 'category'])->where('id', $request->match_id)
            ->first();
        $match->team->member = json_decode($match->team->member);

        $tmp_match_request = [];

        $mm_request = MatchmakingLobbyRequest::where('matchmaking_lobby_id', $match->id)
            ->get()->all();
        foreach ($mm_request as $key => $value) {
            $team_req = Team::join('user_member', 'user_member.id', '=', 'teams.user_member_id')->where('teams.id', $value->team_id)
                ->select('teams.*', 'user_member.name AS captain_name', 'user_member.phone AS captain_phone_number')
                ->first();
            $team_req->member = json_decode($team_req->member);
            $tmp_match_request[] = $team_req;
        }

        $match->request_team = $tmp_match_request;

        return returnAPI(200, 'Success.!', $match);
    }

    /*
    * Payment Method
    */
    public function get_payment_duitku(Request $request)
    {
        // Set kode merchant anda 
        $merchantCode = duitku_config('merchantCode'); 
        // Set merchant key anda 
        $apiKey       = duitku_config('apiKey');
        // catatan: environtment untuk sandbox dan passport berbeda 

        $datetime      = date('Y-m-d H:i:s');  
        $paymentAmount = 10000;
        $signature     = hash('sha256',$merchantCode . $paymentAmount . $datetime . $apiKey);

        $params = array(
            'merchantcode' => $merchantCode,
            'amount'       => $paymentAmount,
            'datetime'     => $datetime,
            'signature'    => $signature
        );

        $params_string = json_encode($params);

        $url = 'https://sandbox.duitku.com/webapi/api/merchant/paymentmethod/getpaymentmethod'; 

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url); 
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params_string);                                                                  
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
            'Content-Type: application/json',                                                                                
            'Content-Length: ' . strlen($params_string))                                                                       
        );   
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

        //execute post
        $req      = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if($httpCode == 200)
        {
            $results = json_decode($req, true);
            return returnAPI($httpCode, 'Success', array_values($results)[0]);
        }else{
            $req = json_decode($req);
            $error_message = "Server Error " . $httpCode ." ". $req->Message;
            return returnAPI($httpCode, $error_message, $req);
        }
    }

    public function request_booking_payment(Request $request)
    {
        $booking_id     = $request->booking_id;
        $payment_method = $request->payment_method;

        $booking_data = Booking::with(['user_member', 'venue'])->where('id', $request->booking_id)->first();
        

        $merchantCode     = duitku_config('merchantCode'); // dari duitku
        $apiKey           = duitku_config('apiKey'); // dari duitku
        $paymentAmount    = $booking_data->total_payment;
        $paymentMethod    = $payment_method; // VC = Credit Card
        $merchantOrderId  = time() . ''; // dari merchant, unik
        $productDetails   = 'Booking Venue'.$booking_data->venue->venue_name.' '.$booking_data->booking_date;
        $email            = $booking_data->user_member->email; // email pelanggan anda
        $additionalParam  = ''; // opsional
        $merchantUserInfo = ''; // opsional
        $customerVaName   = $booking_data->user_member->name; // tampilan nama pada tampilan konfirmasi bank
        $callbackUrl      = url('/api/callback'); // url untuk callback
        $returnUrl        = url('/api/return-exit'); // url untuk redirect
        $expiryPeriod     = 1200; // atur waktu kadaluarsa dalam hitungan menit
        $signature        = md5($merchantCode . $merchantOrderId . $paymentAmount . $apiKey);

        

        // Item detail
        $itemDetails = [];

        $bookingDetail = BookingDetail::where('booking_id', $booking_id)
            ->get()->all();
        foreach ($bookingDetail as $key => $value) {
            if ($value->type == 'field') {
                $field = VenueField::where('id', $value->venue_field_id)->withTrashed()->first();
                $itemDetails[] = [
                    'name'     => $field->field_name.' '.$value->qty.' Hour',
                    'price'    => $value->price*$value->qty,
                    'quantity' => $value->qty
                ];
            }else{
                $tools = SportTools::where('id', $value->sport_tools_id)->withTrashed()->first();
                $itemDetails[] = [
                    'name'     => $tools->tools_name,
                    'price'    => $value->price*$value->qty,
                    'quantity' => $value->qty
                ];
            }
        }

        $params = array(
            'merchantCode'     => $merchantCode,
            'paymentAmount'    => $paymentAmount,
            'paymentMethod'    => $paymentMethod,
            'merchantOrderId'  => $merchantOrderId,
            'productDetails'   => $productDetails,
            'additionalParam'  => $additionalParam,
            'merchantUserInfo' => $merchantUserInfo,
            'customerVaName'   => $customerVaName,
            'email'            => $email,
            'itemDetails'      => $itemDetails,
            'callbackUrl'      => $callbackUrl,
            'returnUrl'        => $returnUrl,
            'signature'        => $signature,
            'expiryPeriod'     => $expiryPeriod
        );
        // debugCode($params);

        $params_string = json_encode($params);
        //echo $params_string;
        $url = 'https://sandbox.duitku.com/webapi/api/merchant/v2/inquiry'; // Sandbox
        // $url = 'https://passport.duitku.com/webapi/api/merchant/v2/inquiry'; // Production
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url); 
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params_string);                                                                  
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
            'Content-Type: application/json',                                                                                
            'Content-Length: ' . strlen($params_string))                                                                       
        );   
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

        //execute post
        $req  = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if($httpCode == 200)
        {
            $booking_data->duitku_detail = $req;
            $booking_data->save();

            $results = json_decode($req, true);
            return returnAPI($httpCode, 'Success', $results);
        }else{
            $req = json_decode($req);
            $error_message = "Server Error " . $httpCode ." ". $req->Message;
            return returnAPI($httpCode, $error_message, $req);
        }
    }

    public function callback(Request $request)
    {

        $d = json_encode($request->all());
        $log = new DuitkuCallbackLog;
        $log->return_callback = $d;
        $log->save();

        $s = json_decode($d);

        $apiKey          = duitku_config('apiKey'); // API key anda
        $merchantCode    = ($s->merchantCode != null)?$s->merchantCode:null;
        $amount          = ($s->amount != null)?$s->amount:null;
        $merchantOrderId = ($s->merchantOrderId != null)?$s->merchantOrderId:null;
        $productDetail   = ($s->productDetail != null)?$s->productDetail:null;
        $additionalParam = ($s->additionalParam != null)?$s->additionalParam:null;
        $paymentMethod   = ($s->paymentCode != null)?$s->paymentCode:null;
        $resultCode      = ($s->resultCode != null)?$s->resultCode:null;
        $merchantUserId  = ($s->merchantUserId != null)?$s->merchantUserId:null;
        $reference       = ($s->reference != null)?$s->reference:null;
        $signature       = ($s->signature != null)?$s->signature:null;

        //log callback untuk debug 
        // file_put_contents('callback.txt', "* Callback *\r\n", FILE_APPEND | LOCK_EX);

        if(!empty($merchantCode) && !empty($amount) && !empty($merchantOrderId) && !empty($signature))
        {
            $params = $merchantCode . $amount . $merchantOrderId . $apiKey;
            $calcSignature = md5($params);

            if($signature == $calcSignature)
            {
                // Update Booking Status
                $booking_data = Booking::where('duitku_detail', 'LIKE', '%'.$reference.'%' )->first();
                $booking_data->status = 1;
                $booking_data->save();
            }else{
                // file_put_contents('callback.txt', "* Bad Signature *\r\n\r\n", FILE_APPEND | LOCK_EX);
                echo 'Bad Signature';
            }
        }
        else
        {
            // file_put_contents('callback.txt', "* Bad Parameter *\r\n\r\n", FILE_APPEND | LOCK_EX);
            echo 'Bad Parameter';
        }
    }
}
