<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Venue;
use App\Models\VenueField;
use App\Models\Province;
use App\Models\Regency;
use App\Models\Category;

class VenueController extends Controller
{

    /*
    * Venue Function
    */
    public function index(Request $request)
    {
        $session_user   = $request->session()->get('auth_user');
        $data = Venue::with(['province', 'regency'])->where('user_id', $session_user->id)->get()->all();
        // debugCode($data);
        return view('venue.index', compact('data'));
    }

    public function create()
    {
        $province    = Province::orderBy('name', 'ASC')->get()->all();
        return view('venue.create', compact('province'));
    }

    public function store(Request $request)
    {
        // debugCode($request->all());
        $session_user   = $request->session()->get('auth_user');

        $data = new Venue;
        $data->user_id     = $session_user->id;
        $data->venue_name  = $request->name;
        $data->province_id = $request->province;
        $data->regency_id  = $request->city;
        $data->lat         = $request->lat;
        $data->lng         = $request->lng;
        $data->open_time   = $request->opening;
        $data->close_time  = $request->closing;
        $data->save();

        return redirect('/venue')->with('success','Add data success.!');
    }

    public function show($id)
    {
        $data        = Venue::find($id);
        $province    = Province::orderBy('name', 'ASC')->get()->all();
        $city        = Regency::where('province_id', $data->province_id)->orderBy('name', 'ASC')->get()->all();
        return view('venue.edit',compact('data', 'province', 'city'));
    }

    public function update(Request $request, $id)
    {
        $data = Venue::find($id);
        $data->venue_name  = $request->name;
        $data->province_id = $request->province;
        $data->regency_id  = $request->city;
        $data->lat         = $request->lat;
        $data->lng         = $request->lng;
        $data->open_time   = $request->opening;
        $data->close_time  = $request->closing;

        $data->save();

        return redirect('/venue')->with('success','Update data success.!');
    }

    public function destroy($id)
    {
        Venue::find($id)->delete();
        return redirect('/venue')->with('success','Delete data success.!');
    }

    /*
    * Admin Venue Function
    */
    public function admin_index()
    {
        $data = Venue::with(['province', 'regency'])->get()->all();
        // debugCode($data);
        return view('admin_venue.index', compact('data'));
    }

    public function admin_create()
    {
        $venue_owner = User::where('roles', 'venue')->orderBy('name', 'asc')->get()->all();
        $province    = Province::orderBy('name', 'ASC')->get()->all();
        return view('admin_venue.create', compact('venue_owner', 'province'));
    }

    public function admin_store(Request $request)
    {
        // debugCode($request->all());
        $data = new Venue;
        $data->user_id     = $request->user_id;
        $data->venue_name  = $request->name;
        $data->province_id = $request->province;
        $data->regency_id  = $request->city;
        $data->lat         = $request->lat;
        $data->lng         = $request->lng;
        $data->open_time   = $request->opening;
        $data->close_time  = $request->closing;
        $data->save();

        return redirect('/admin-venue')->with('success','Add data success.!');
    }

    public function admin_show($id)
    {
        $data        = Venue::find($id);
        $venue_owner = User::where('roles', 'venue')->orderBy('name', 'asc')->get()->all();
        $province    = Province::orderBy('name', 'ASC')->get()->all();
        $city        = Regency::where('province_id', $data->province_id)->orderBy('name', 'ASC')->get()->all();
        return view('admin_venue.edit',compact('data', 'venue_owner', 'province', 'city'));
    }

    public function admin_update(Request $request, $id)
    {
        $data = Venue::find($id);
        $data->user_id     = $request->user_id;
        $data->venue_name  = $request->name;
        $data->province_id = $request->province;
        $data->regency_id  = $request->city;
        $data->lat         = $request->lat;
        $data->lng         = $request->lng;
        $data->open_time   = $request->opening;
        $data->close_time  = $request->closing;

        $data->save();

        return redirect('/admin-venue')->with('success','Update data success.!');
    }

    public function admin_destroy($id)
    {
        Venue::find($id)->delete();
        return redirect('/admin-venue')->with('success','Delete data success.!');
    }

    /*
    * Venue Field
    */

    public function venue_field_index($venue_id)
    {
        $data     = VenueField::with(['category'])->where('venue_id', $venue_id)->get()->all();
        $venue    = Venue::with(['province', 'regency', 'user'])->where('id', $venue_id)->first();
        $category = Category::get()->all();
        // debugCode($venue);
        return view('venue_field.index', compact('data', 'venue', 'category'));
    }

    public function venue_field_store(Request $request, $venue_id)
    {
        $data = new VenueField;
        $data->venue_id    = $venue_id;
        $data->field_name  = $request->name;
        $data->category_id = $request->category;
        $data->price       = $request->price;
        $data->save();

        return redirect()->back()->with('success', 'Add Field Success.!');
    }

    public function venue_field_update(Request $request, $venue_id, $id)
    {
        $data = VenueField::find($id);
        $data->venue_id    = $venue_id;
        $data->field_name  = $request->name;
        $data->category_id = $request->category;
        $data->price       = $request->price;
        $data->save();

        return redirect()->back()->with('success', 'Update Field Success.!');
    }

    public function venue_field_delete($venue_id, $id)
    {
        $data = VenueField::find($id)->delete();
        return redirect()->back()->with('success', 'Delete Field Success.!');
    }
}
