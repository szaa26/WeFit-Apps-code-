<?php
use Illuminate\Http\Request;
use App\Models\Booking;


if (! function_exists('debugCode')) {
    function debugCode($r=array(),$f=TRUE)
    {
        echo "<pre>";
        print_r($r);
        echo "</pre>";

        if($f==TRUE) 
            die;
    }
}

function selected($par1, $par2)
{
    return ($par1 == $par2)?"selected":'';
}

function calculate_days($date1, $date2)
{
    $diff   = abs(strtotime($date2) - strtotime($date1));
    $years  = floor($diff / (365*60*60*24));
    $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
    $days   = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
    return $days;
}

function status_booking($code = 0)
{
    $status = [
        [
            'color'  => '#c0392b',
            'status' => 'Waiting for payment'
        ],
        [
            'color'  => '#27ae60',
            'status' => 'Paid'
        ],
        [
            'color'  => '#7f8c8d',
            'status' => 'Cancelled'
        ]
    ];

    return $status[$code];
}

if (! function_exists('returnAPI')) {
    function returnAPI($code = 200, $message = "", $data = [])
    {
        $status = 'success';
        if ($code !== 200) {
            $status = 'failed';
        }
        $returnArray = [
            'code'    => $code,
            'status'  => $status,
            'message' => $message,
            'data'    => $data
        ];

        return response()->json($returnArray);
    }   
}

function duitku_config($sel = '')
{
    $config = [
        'merchantCode' => 'DS15008',
        'apiKey'       => 'dd74902691ff3007f57e1cf3b86d9f16'
    ];

    if ($sel != '') {
        return $config[$sel];
    }else{
        return $config;
    }
}

function generate_booking_code()
{
    $count = Booking::count();
    $next_num = $count+1;

    $number_text = "";
    if ($next_num < 10) {
        $number_text = '0000'.$next_num;
    }elseif($next_num < 100){
        $number_text = '000'.$next_num;
    }elseif($next_num < 1000){
        $number_text = '00'.$next_num;
    }elseif($next_num < 10000){
        $number_text = '0'.$next_num;
    }elseif($next_num < 100000){
        $number_text = $next_num;
    }

    $invoice = 'INV-'.date('Ymd').$number_text;
    return $invoice;
}


function status_mm($code = 0)
{
    $status = [
        [
            'color'  => '#c0392b',
            'status' => 'Finding Opponent'
        ],
        [
            'color'  => '#27ae60',
            'status' => 'Finish'
        ],
    ];

    return $status[$code];
}

function total_balance($user_id=0)
{
    $data = Booking::join('venue', 'venue.id', '=', 'booking.venue_id')->where('venue.user_id', $user_id)
        ->where('status', 1)
        ->where('withdrawal_status', 0)
        ->sum('total_payment');
    return $data;
}

function status_withdrawal($status='')
{
    $list = ['Pending', 'Complete'];

    if ($status == '') {
        return $list;
    }else{
        return $list[$status];
    }
}